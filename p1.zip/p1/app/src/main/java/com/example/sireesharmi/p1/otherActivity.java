package com.example.sireesharmi.p1;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.os.PersistableBundle;

import java.net.URI;
import java.net.URLConnection;

/**
 * Created by Sireesharmi on 01-08-2016.
 */
public class otherActivity extends Activity {

    ListView listView;
    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        setContentView(R.layout.other_layout);

        listView = (ListView) findViewById(R.id.list);
        String[] pics={"Search us in Google","Follow us on facebook","Mail us at gmail","Follow us in Twitter"};

        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(this,R.layout.myyyyy,pics);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int pos=position;
                if(pos==0)
                    Uri.parse("www.google.com");
                if(pos==1)
                    Uri.parse("www.facebook.com");
                if(pos==2)
                    Uri.parse("www.gmail.com");
                if(pos==3)
                    Uri.parse("www.twitter.com");
                }

            }
        );
    }
}
