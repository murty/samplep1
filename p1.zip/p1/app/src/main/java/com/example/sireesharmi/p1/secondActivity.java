package com.example.sireesharmi.p1;

import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Sireesharmi on 30-07-2016.
 */
public class secondActivity extends Activity implements View.OnClickListener{

    EditText rname, rpass, rmob, rmail;
    Button add;

    Context context=this;
    UserDatabase userDatabase;
    SQLiteDatabase sqLiteDatabase;

    String ename;
    String epass;
    String emob;
    String email;


    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        setContentView(R.layout.new_contact_layout);

        rname = (EditText) findViewById(R.id.reditname);
        rpass = (EditText) findViewById(R.id.reditpass);
        rmob = (EditText) findViewById(R.id.reditmob);
        rmail = (EditText) findViewById(R.id.reditmail);
        add = (Button) findViewById(R.id.add);

    }
    public void addUser(View v)
    {
         ename = rname.getText().toString();
         epass = rpass.getText().toString();
         emob = rmob.getText().toString();
         email = rmail.getText().toString();

        userDatabase = new UserDatabase(context);
        sqLiteDatabase = userDatabase.getWritableDatabase();
        userDatabase.add(ename, epass, emob, email, sqLiteDatabase);
        Toast.makeText(getBaseContext(), "Inserted", Toast.LENGTH_LONG).show();
        userDatabase.close();

    }

    @Override
    public void onClick(View v) {
        int id=v.getId();
        if(id==R.id.add){
            addUser(v);
        }
    }
}

