package com.example.sireesharmi.p1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.PersistableBundle;

public class MainActivity extends AppCompatActivity {

    Button signin;
    Button Register;
    EditText name;
    EditText pass;

    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        setContentView(R.layout.activity_main);

        signin=(Button)findViewById(R.id.sign);
        name=(EditText)findViewById(R.id.editname);
        pass=(EditText) findViewById(R.id.editpass);
        Register=(Button)findViewById(R.id.register);

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,otherActivity.class);
                startActivity(i);
            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,secondActivity.class);
                startActivity(intent);
            }
        });

    }
}
