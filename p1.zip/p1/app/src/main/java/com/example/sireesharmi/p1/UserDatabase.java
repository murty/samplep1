package com.example.sireesharmi.p1;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by Sireesharmi on 31-07-2016.
 */
public class UserDatabase extends SQLiteOpenHelper {

    private static final String DB_NAME="localdb";
    private static final int DB_VER=1;
    private static final String USER_NAME="name";
    private static final String USER_PASS="pass";
    private static final String USER_MOB="mobile";
    private static final String USER_MAIL="mail";
    private static final String TABLE_NAME="userinfo";
    private static final String QUERY="CREATE TABLE "+TABLE_NAME+"("+USER_NAME+" TEXT"+USER_PASS+" TEXT"+USER_MOB+" TEXT"+USER_MAIL+" TEXT);";

    Context context;
    public  UserDatabase(Context context)
    {
        super(context,DB_NAME,null,DB_VER);
        Log.e("DB OPERATIONS","db created");
    }
    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(QUERY);
        Toast.makeText(context,"Created",Toast.LENGTH_LONG).show();
        Log.e("DB OPERATIONS","table created");
    }

    public void add(String name,String pass,String mob,String mail,SQLiteDatabase db)
    {
        ContentValues contentValues=new ContentValues();
        contentValues.put(USER_NAME,name);
        contentValues.put(USER_PASS,pass);
        contentValues.put(USER_MOB,mob);
        contentValues.put(USER_MAIL,mail);
        db.insert(TABLE_NAME,null,contentValues);
        Log.e("DB OPERATIONS","row inserted");
        db.close();
        Toast.makeText(context,"Saved",Toast.LENGTH_LONG).show();
    }
    @Override

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
